'''
	Apply the mentioned formula
    https://en.wikipedia.org/wiki/Determination_of_the_day_of_the_week#Disparate_variation
'''

w = 2
print('sun mon tue wed thu fri sat')
for var in range(1,31):
    print(f'{var:<4}', end='')
    if var%7==0:
        print()
    