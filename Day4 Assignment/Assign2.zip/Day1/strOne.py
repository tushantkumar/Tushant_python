'''
	Dealing with strings
'''
#[begin:end:step]

string = 'Hello how are you'

print(f'1. {string}')
print(f'2. {string[:]}')

print(f'3. {string[:5]}')
print(f'4. {string[::]}')
print(f'7. {string[5:]}')
print(f'5. {string[::3]}')

print(f'2. {string[-1:-6:-1]}')
print(f'6. {string[::-1]}')