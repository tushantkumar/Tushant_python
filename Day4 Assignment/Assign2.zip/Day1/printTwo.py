varA = 10 #int
varB = 10.234 #float 
varC = 'String here' #string


print('Int: {}\tFloat: {}\tString: {}'.format(varA, varB,varC))

print('Var 1: {1}\tVar 2: {2}\tVar 3: {0}'.format(varA, varB,varC))

print(f'Var 1: {varC}\tVar 2: {varB}\tVar 3: {varA}')

print(f'Var 1: {varC * 2}\tVar 2: {varB * 2}\tVar 3: {varA * 2}')



