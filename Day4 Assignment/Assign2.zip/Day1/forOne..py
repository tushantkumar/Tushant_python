for var in range(1,10):	
    print(var, end = ' ')
	