'''
	sets and dictionary
'''


var = {1,2,3,4,5,5,6,4,3,3} # set
print(var,type(var))
var = {1:'a', 2:'b',3:'c'}
print(var,type(var))