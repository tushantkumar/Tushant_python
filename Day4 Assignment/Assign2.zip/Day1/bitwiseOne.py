'''
	bitwise expressions here
	
'''

var = 10
print(f'{var:3}-->{var:b}--> {var:o}-->{var:x}')
var = ~var
print(f'{var:3}-->{var:b}--> {var:o}-->{var:x}')