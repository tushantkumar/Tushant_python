print(True)
print(False)

string = 'abcdefghij'

print(f"Testing : {'a' in string}")
if 'a' in string:
    print(True)
    
if 'X' in string:
    print(True)
else:
    print(False)
