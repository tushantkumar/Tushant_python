'''
	sets and dictionary
'''
inpStr = '1010'

var = {'0','1'}
testSet = set(inpStr)
print(f'test: {testSet}')
if var == testSet or testSet=={'0'} or testSet == {'1'}:
    print("True")
else:
    print("False")


