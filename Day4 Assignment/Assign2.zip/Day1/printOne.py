varA = 10 #int
varB = 10.234 #float 
varC = 'String here' #string
print('Int: %d\tFloat: %f\tString: %s' % (varA,varB,varC))