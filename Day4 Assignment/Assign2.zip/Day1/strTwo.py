'''
	some of the string methods
'''
string = 'hello how are you'

print(string)
print(string.capitalize())
print(string.title())
print(string.swapcase())
print(string.center(40,'*'))