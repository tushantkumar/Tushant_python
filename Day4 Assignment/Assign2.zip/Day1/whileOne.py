var = 10
while var>0:
	print(var, end = ' ')
	var-=1