a,b,c = '10','20','30'

print(type(a),type(b),type(c))
print(a,b,c)

month =  int(input('enter month'))
Year =  int(input('enter Year'))

print(f'month:{month} --> Year {Year}')
/////2019 --> 20 C --> 19 --> y