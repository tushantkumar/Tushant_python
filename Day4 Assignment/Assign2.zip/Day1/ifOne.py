var = 151
if var==10:
    print(f'10 is {True}')
elif var==15:
    print(f'15 is {True}')
else:
    print(f'{False}')
