'''
	Testing with lists

var = 'string here'
lstOne = list(var)
print(lstOne, type(lstOne))
lstOne[0] = 'H'
print(lstOne)
print(lstOne[::-1])
'''


var = [
    [123,'Name One' , 12300.00],
    [122,'Name Two' , 12200.00],
]
print(var)

var[0][1]='Ram'
print(var[0])
var[1][1]='Ravi'
print(var[1])

var = (123,'Name Here' , 12300.00)
print(var, type(var))
var=10,20,30
print(var, type(var))
var=10,
print(var, type(var))
var = (123,'Name Here' , 12300.00)
var[0] = 200
print(var, type(var))


