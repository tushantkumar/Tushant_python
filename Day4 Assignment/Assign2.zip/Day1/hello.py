print("Hello World")
print('Hello World')
print('''Hello World''')
print("""Hello World""")
# Comments here
'''
    This we will talk about it in detail
    tomorrow
'''
#Primitive data types in python
varA = 10 #int
varB = 10.234 #float 
varC = 'String here' #string

print(varA,varB,varC)
