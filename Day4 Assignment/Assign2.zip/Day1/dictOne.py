'''
'clear', 'copy', 'fromkeys', 'get', 'items', 'keys', 'pop', 'popitem', 'setdefault', 'update', 'values'
'''
nums={'one':1, 'two':2,
 'twenty':20,'thirty':30,'forty':40,'hundred':100,
'thousand':1000, 'lakh':100000, 'crore':10000000}

print(nums.keys())

print(nums.get('two'))

