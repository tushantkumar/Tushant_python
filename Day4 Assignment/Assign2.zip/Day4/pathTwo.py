'''
	Introduction to pathlib
'''

from pathlib import Path
#directory / folders

path =Path()
print(path.exists())
print(path.absolute())

'''
for p in path.iterdir():
    print(p)
    
# you cannot use *.*, *.py, *.txt

lst = [str(p) for p in path.iterdir()]
print(lst)
'''    

#rglob is recursive, glob only specified directory
lst = [p for p in path.rglob("*.py")]
print(lst)


