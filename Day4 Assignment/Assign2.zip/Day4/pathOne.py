'''
	Introduction to pathlib
'''

from pathlib import Path
'''
var = Path()
print(f'{var}')
'''
p = Path(Path() / 'testDir'/'file.txt')
print(p)
print(p.exists())

p = Path(Path() / 'MyPackage'/'my_function_file.py')
print(p)
print(p.exists())
print(p.is_file())
print(p.is_dir())
print(p.absolute())

var = p.with_name('myFile.txt')
print(var)

var1 = p.with_suffix('.asm')
print(var1)

'''
shutil
ulink('name.txt')
copy(source,dest)
'''