import time
from functools import lru_cache

def decorator(func):
    def wrapper(args):
        start = time.perf_counter()
        func(args)
        end = time.perf_counter()
        print(f'\nCompleted in {round(end-start,5)} secs')
    return wrapper

@lru_cache
def myFibonacci(num):
    if num<=1:
        return num
    else:
        return myFibonacci(num-1) + myFibonacci(num - 2)
        
@decorator
def Fibo(num):        
    for i in range(num):
        print(myFibonacci(i),end=' ')

Fibo(400)