import re

with open('D:\\Sify documents\\Python training\\Assignment\\Day4 Assignment\\regex.html') as f:
    pat = re.compile('\w{4,}')
    for line in f.readlines():
        res = re.sub(pat,'XXXX',line)
        print(res)