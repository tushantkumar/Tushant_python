
def decorator(fun):	
    print('Start')
    def wrapper(args):
        ret = fun(args)
        return ret
    print('Complete')
    return wrapper
    
@decorator 
def myFactorial(num):
    if num<=1:
        return 1
    return num * myFactorial(num-1)

    
'''
def fibonacci(num):
    if num<=1:
        return num
    return fibonacci(num-1)+fibonacci(num-2)
'''    
    
ret = myFactorial(5)
print(f'{ret}')