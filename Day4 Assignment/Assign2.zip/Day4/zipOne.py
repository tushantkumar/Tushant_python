from pathlib import Path
from zipfile import ZipFile
#rglob is recursive, glob only specified directory

zipper = ZipFile('myTest.zip','w')
path = Path()
for p in path.rglob("*.py"):
    zipper.write(p)
zipper.close()

with ZipFile('myTest.zip') as zp:
    print(zp.namelist())
    info = zp.getinfo('reOne.py')
    print(f'{info.file_size}-->{info.compress_size}')
    
    #zp.extract('reOne.py')
    #zp.extractall('destDir/')