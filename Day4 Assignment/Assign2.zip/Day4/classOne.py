'''
	Introduction to Classes & Objects
'''

class Name:
	pass
	

obj = Name()
