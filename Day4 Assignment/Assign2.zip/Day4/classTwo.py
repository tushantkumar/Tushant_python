'''
    in Classes. functions/methods
    variables / attributes

'''

class Name:
    var = 'class Name here'
    
	

obj = Name()
print(obj)

print(obj.var)
