'''
    in Classes. functions/methods
    variables / attributes

'''

class Name:
    # var = 'class Name here'
    def fun(self):
        self.var= 'some string here'
        print('Inside fun')
        return self.var
	

obj = Name()
print(obj)



print(f'calling fun {obj.fun()}')
print(obj.var)