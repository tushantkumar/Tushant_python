'''
    Special methods for a class in python
    __init__ --> constructor
    __str__ --> print object or str(obj)
'''


class Student:
	def __init__(self):
		print('Student Class constructor')

	def __str__(self):
		return f'student object...'

    def acceptDetails():
        pass
    def dispDetails():
        pass
        
    
var = Student()
print(var)
    