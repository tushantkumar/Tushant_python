import re

'''
#search returns match object
res = re.search('is','This is my first line')
print(res.string)
print(res.span())
beg,end = res.span()
print(res.string[beg:end])

#retuns a list of strings separated by the pattern 
res = re.split('who', 'Thiswhoiswhomywhofirstwholine')
print(res)


#retuns a list of strings separated by the pattern
res = re.findall('\w{4,}','This is my first line')
print(res)
'''

#find and replace the given pattern with replacement string on any given string 
res = re.sub('\w{4,}','XXXX','This is my first line')
print(res)

