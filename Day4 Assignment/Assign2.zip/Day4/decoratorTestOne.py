from functools import lru_cache
def decorator(fun):    
    def wrapper(args):
        print('Start')
        fun(args)
        # return ret
        print('Complete')
    return wrapper
    
@lru_cache(maxsize=None)
def fibonacci(num):
    if num<=1:
        return num
    return fibonacci(num-1)+fibonacci(num-2)

@decorator
def myFibo(num):
    for i in range(num):
        print(f'{i}-->{fibonacci(i)}')
        
        
myFibo(40)