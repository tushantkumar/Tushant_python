class Singleton:
	__instance = None
	@staticmethod
	def getInstance():
		if Singleton.__instance == None:
			Singleton()
		return Singleton.__instance
    
	def __init__(self):
		if Singleton.__instance == None:
			Singleton.__instance = self
		else:
			raise Exception('You cannot have a new instance')
            
	def disp(self):
		print(self.__instance)
        
sobj = Singleton()
print(sobj)

s1 = Singleton.getInstance()
print(s1)

s2 = Singleton.getInstance()
print(s2)

s3 = Singleton.getInstance()
print(s3)

s4 = Singleton()
print(s4)

s4.disp()