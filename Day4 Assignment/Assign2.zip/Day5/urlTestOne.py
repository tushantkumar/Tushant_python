'''
'''

import urllib.request as url
import ssl

contxt = ssl.create_default_context()
contxt.check_hostname=False
contxt.verify_mode = ssl.CERT_NONE

lnk = 'https://docs.python.org' 
page = url.urlopen(lnk, context=contxt)
print(page.read())


