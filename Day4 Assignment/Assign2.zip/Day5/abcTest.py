from abc import ABC, abstractmethod

class Wonders(ABC): #abstract class
    def __init__(self):
        print('Its a wonder')

    @abstractmethod
    def what(self):
        pass
        
        
class TajMahal(Wonders):# abstract class
    pass
    
class TowerOfPisa(Wonders): #concrete classes
    def what(self):
        print('Not as good as Lal bagh')
        
obj = TowerOfPisa()
obj.what()

    
