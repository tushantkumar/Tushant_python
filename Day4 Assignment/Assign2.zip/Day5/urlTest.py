'''
'''

import urllib.request as url

lnk = 'http://ramakrishnavivekananda.info/' 
page = url.urlopen(lnk)
# print(page.read())

with open('file.html','w') as fileObj:
    fileObj.write(str(page.read()))