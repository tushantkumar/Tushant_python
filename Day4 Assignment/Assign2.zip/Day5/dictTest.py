team_data={
  1: {
    "Team": {
      "1": "Aus",
      "2": "India"
    }
  },
  2: {
    "Team": {
      "1": "Aus",
      "2": "India"
    }
  }
}

print(team_data)