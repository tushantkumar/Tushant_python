import json

#tuple for keys in python
#list cannot be passed as keys
'''
vsCodeRunner = {
	'CPP':'g++',
	'C': 'gcc',
	'python':'python3',
	'java':'gcj'
}
'''
Players = { 'Australia':{{'David Warner': [123,67,54]},	{'Steve Smith': [23,65,53]}},'India':{	{'Virat Kohli': [54,38,99]},{'Harthik Pandya': [97,78,67]}}}
print(Players)


with open('compInfo.json','w') as obj:
    json.dump(Players, obj)
