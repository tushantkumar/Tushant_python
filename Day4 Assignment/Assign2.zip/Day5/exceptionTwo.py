class MyError(Exception):
    pass
	
class YourError(MyError):
    pass
		
try :
    print('one')
    raise YourError('Your Type of error')
    print('Two')
except YourError as ye:
    print(f'2. {ye}')
except MyError as me:
    print(f'1. {me}')
