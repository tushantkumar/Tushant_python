from abc import ABC, abstractmethod

class GameObject(ABC):
    @abstractmethod
    def collide(self):
        pass
        
class spaceShip(GameObject):
    def collide(self):
        print('Ship collides')    

class Asteroid(GameObject, someOtherClass):
    def collide(self):
        print('Asteroid collides')
        
def spaceStationCollides(gObj):
    print ('The station is damaged because ')
    gObj.collide()
    print('Evacuate the station')
    print('-' * 30)
    
    
sp = spaceShip()
ast = Asteroid()

spaceStationCollides(sp)
spaceStationCollides(ast)

