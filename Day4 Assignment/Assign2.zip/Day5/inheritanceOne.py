'''
	Inheritance
	Base ---> Derived
	Super --> subclass
	General --> Specialized
'''

class Person:
    def __init__(self, name='AAA', age='20'):
        self.name, self.age = name,age 
    
    def __str__(self):
        return f'Name {self.name}\t\tAge {self.age}'
        

class Trainee(Person):
    def __init__(self,name='AAA', age=22, company='Sify Corp', desg='Trainee'):
        super().__init__(name,age)
        self.comp, self.desg = company, desg
        
    def __str__(self):
        return f'{super().__str__()} --> comp {self.comp}\t\t Desg: {self.desg}'
            
            
obj = Trainee('Tushant')
print(obj)
print(type(obj))
print(issubclass(Trainee, Person))
print(issubclass(Person,Trainee))
print('*' * 30)
print(isinstance(obj, Trainee))
print(isinstance(obj, Person))
print(isinstance(obj, object))
print('*' * 30)