class ContextManager:
	def __init__(self):
		self.data = 'some data here'       
        
	def __str__(self):
		return self.data
        
	def __enter__(self):
		print('Entering ...')
        
	def __exit__(self,*args):
		print('Exiting...')
        
        
with ContextManager() as obj:
	print(obj)
    
    
    
    
