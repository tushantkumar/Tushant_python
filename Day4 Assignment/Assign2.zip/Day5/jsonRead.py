'''
	Reading from json files
    dump --> writing into the file
    load --> reading from the file
    
'''
import json
with open('compInfo.json') as rObj:
	val = json.load(rObj)
    
print(val)