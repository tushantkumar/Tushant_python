'''
Exception Handling
'''
import sys

num1 = 10
num2 = 0
try:
    print('one')
    num1 + 'num2'
    print('two')
except ValueError: # handle TypeError
	print('Incompatible Operation')
except (TypeError, ZeroDivisionError): # handle TypeError
	print('TypeError/ZeroDivisionError Operation')
except: # all types of exception 
    print('Some kind of exception')
    print(f'{sys.exc_info()}')
    
    print(f'{sys.exc_info()[0]}')
    print(f'{sys.exc_info()[0].__name__}')
    
    print(f'{sys.exc_info()[1]}')
    
    