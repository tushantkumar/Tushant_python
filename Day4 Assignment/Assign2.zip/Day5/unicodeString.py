'''
	unicode string example
'''

s ='a\xac\u1234\u20ac\U00008000'
print(s)
print(s.encode('utf-8'))
print(s.encode('utf-16'))
print(s.encode('utf-32'))

st = s.encode('utf-8')
print(st.decode('utf-8'))
st = s.encode('utf-16')
print(st.decode('utf-16'))
st = s.encode('utf-32')
print(st.decode('utf-32'))

