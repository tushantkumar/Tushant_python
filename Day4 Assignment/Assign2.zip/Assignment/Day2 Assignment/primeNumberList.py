import MyPackage.modulePrime as mprime

mprime.getPrime()