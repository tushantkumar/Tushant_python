'''
	demonstrate the usage of function stack
'''

def recur(num):
    if num<=5:
        print(f'{num} ',end=' ')
        recur(num+1)
        print(f'{num} ',end=' ')
        
recur(1)