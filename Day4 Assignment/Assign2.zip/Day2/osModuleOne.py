'''
	import os module
'''

import os

# print(f'Path: {os.path}')
os.system('cls')
print(f'Path: {os.path.abspath(os.curdir)}')
print(f'Path: {os.curdir}')
os.system('dir')