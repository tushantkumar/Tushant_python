'''
	sys module
'''

import sys

print(f'Sys: {sys.argv}')
print(f'WinVer: {sys.winver}')
print(f'Sys: {sys.argv[1:]} --> {len(sys.argv)}')