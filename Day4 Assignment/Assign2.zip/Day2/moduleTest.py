'''
	Intro to modules
'''

import moduleOne

moduleOne.funOne()
moduleOne.funTwo()
