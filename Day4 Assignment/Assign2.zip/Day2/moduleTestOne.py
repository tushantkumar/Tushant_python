'''
	Intro to modules
    using the functions defined in
    moduleOne.py
'''

from moduleOne import funOne, funTwo

funOne()
funTwo()
