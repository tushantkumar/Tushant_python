collect = (i+j for i in range(10) for j in range(5))

print(f'collect-->{collect}')
for i in collect:
    print(i, end=' ')
