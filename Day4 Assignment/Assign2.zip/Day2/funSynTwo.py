'''
	fun syntax 1
'''
def funOne(arg):
    print(f"funOne({arg})")
    def funInner(arg):
        print(f'funInner-->{arg}')
    funInner(arg)
    
    
funOne(10)

    
