collect = [i+j for i in range(10) for j in range(5)]

coll2D = [collect[i*5:i*5+5] for i in range(10)]
print(f'collect-->{collect}')
print(f'coll2D-->{coll2D}')