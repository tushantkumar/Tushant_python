'''
	intro to generators
'''

def funOne(arg):
	print(f'funOne {arg}')
	yield arg+1
	
print(funOne(10))