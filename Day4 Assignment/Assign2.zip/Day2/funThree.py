'''
	
'''

def funName():    
    print(f'Inside funName() {funName.__name__}')
    return 10,20,30
	
    
# print(f'function Returns: {funName()}')
for var in funName():
    print(var)
    

