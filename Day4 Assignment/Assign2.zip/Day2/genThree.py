'''
	intro to generators
'''

def funOne(arg):
    print(f'one {arg}')
    yield arg+1
    print(f'two {arg}')
    yield arg+2
    print(f'three {arg}')
    yield arg+3
    print(f'four {arg}')
    yield arg+4
	
ret = funOne(10)
print(next(ret))
print(next(ret))
print(next(ret))
print(next(ret))
print(next(ret))

