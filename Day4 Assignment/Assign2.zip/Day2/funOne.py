'''
	Intro to functions
'''

def funName():
    print('Inside funName()')
    return 10
	
    
print(f'function Returns: {funName()}')