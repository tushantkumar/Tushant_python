'''
	Intro to modules
'''
def funOne():
    print(f'funOne called--> {__name__}')
    
def funTwo():
    print(f'funTwo called--> {__name__}')
        

if __name__ == '__main__':
    funOne()
    funTwo()
    
   