'''
	fun syntax 1
'''
def funOne(arg):
    print(type(arg),end=' ')
    print(f"funOne({arg})")
    
funOne(10)
funOne([10,20,30])
funOne((10,20,30))
funOne({10,20,30})
funOne('string here')

