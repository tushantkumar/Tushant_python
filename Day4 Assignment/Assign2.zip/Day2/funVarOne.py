'''
	functions and variables
'''
var = 10
def outerFun():
    var = 20
    print(f'1. OuterFun var-->{var}')
    def InnerFun():
        nonlocal var
        var+=10
        print(f'InnerFun var-->{var}')

    InnerFun()
    print(f'2. OuterFun var-->{var}')
    
print(f'1. global {var}')
outerFun()
print(f'2. global {var}')