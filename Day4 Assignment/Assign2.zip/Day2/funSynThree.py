'''
	fun syntax 1
'''
def college(arg):
    print(f"college({arg})")
    def branch(arg):
        print(f'branch-->{arg}')
        def Class():
            print(f'Class')
            
        Class()
    branch(arg)
    
college(10)

    
