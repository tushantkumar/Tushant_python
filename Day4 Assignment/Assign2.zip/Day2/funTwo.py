'''
	Intro to functions
    __name__ --> dunder name
    __init__ --> dunder init
    __doc__ --> dunder doc
    docstring
'''

def funName():
    
    '''
        intro to funName()-->int
    '''
    print(f'Inside funName() {funName.__name__}')
    return 10
	
    
print(f'function Returns: {funName()}')
print(f'__doc__  --> {__doc__}')
print(f'function doc: {funName.__doc__}')

