collGen = (i+j for i in range(10) for j in range(5))

print(f'1. collect-->{collGen}')
for i in collGen:
    print(i, end=' ')
print()

collList = [i+j for i in range(10) for j in range(5)]

print(f'2. collect-->{collList}')
for i in collList:
    print(i, end=' ')
print()