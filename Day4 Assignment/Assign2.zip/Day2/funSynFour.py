'''
	fun syntax 1
'''
def college(arg):
    print(f"college({arg})")
    def branch(arg):
        print(f'branch-->{arg}')
        def Class():
            print(f'Class')            
        return Class
    return branch

ret1 = college(10)
ret2 = ret1(20)
ret2()
    
