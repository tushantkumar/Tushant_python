'''
	Intro to modules from package
'''
import myPackage.moduleOne as mpm

mpm.funOne()
mpm.funTwo()
