collect = [i**2 for i in range(10)]

print(collect)