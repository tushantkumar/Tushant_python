'''
	
'''
def sub(x):
    return x - (x-1)
def divi(x):
    return x//sub(x+1)
def addi(x):
    return x + divi(x+1)
def multi(x):
    return x*addi(x+1)
def funName(x):    
    return x+multi(x+1)
	
print(f'funName -->{funName(2)}')
  #a 2 , b 0 ,c 4 d 29 e 27 f 28
  

