def logInfo(funAsArg):
    import time
    start_time = time.perf_counter()
    def wrapperLog(arg):
        var=funAsArg(arg)
        return var
    end_time = time.perf_counter()
    print(round(end_time - start_time,5))
    print('-'*50)    
    return wrapperLog   


@logInfo
def recur_fibo(n):
    if n <= 1:
        return n
    else:
       return(recur_fibo(n-1) + recur_fibo(n-2))
nterms = 20
print("Fibonacci Series is:")
for i in range(nterms):
       print(recur_fibo(i), end=" ")
   
@logInfo
def recur_factorial(n):
    if n == 1:
        return n
    else:
        return n*recur_factorial(n-1)    
num = 5
print("The factorial of", num, "is", recur_factorial(num))      
recur_fibo(20)
recur_factorial(5)