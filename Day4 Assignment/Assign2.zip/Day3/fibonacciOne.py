'''
memoization--> remembering the previous results
Least Recently Used --> lru_cache
'''
from functools import lru_cache

@lru_cache(maxsize=32)
def  fibonacci(number):
    if number<= 1:
        return number
    else:    
        return (fibonacci(number-1)+fibonacci(number-2))        
    
import sys
import time
# numbers=int(input("enter number of terms"))
start = time.perf_counter()
print("fibonacci series:")
for i in range(int(sys.argv[1])):
    print(f'{i+1} -->{fibonacci(i)}')
print()
print(f'{round(time.perf_counter() - start, 5)} seconds')