'''
Modes:
    r, w, a

    obj = open(path,mode)#loading contents from disk to memory
    obj.read()
    obj.readline()
    obj.write()
    obj.close()#write back the contents from buffer/memory to disk
'''

fObj = open('c:\\Users\\sudhakar\\Desktop\\TrainingSify\\Day3\\fileOne.py','r')
text = fObj.read()
print(text)
print(len(text))
fObj.close()