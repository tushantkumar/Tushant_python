'''
Decorators with args
'''
import time

def callerFun(fun):
    endTime=0
    start = time.perf_counter()
    def decorator(arg):
        nonlocal endTime
        def wrapFun():
            var =  fun(arg)
                
            return var
        endTime = time.perf_counter()
        return wrapFun
    
    print(f'{round(endTime-start, 4)}')
    return decorator



@callerFun
def recur_fibo(n):    
    if n <= 1:
        #print(n)
        return n
    else:
        return(recur_fibo(n-1) + recur_fibo(n-2))

nterms = 20
print("Fibonacci Series is:")
for i in range(nterms):
    print(recur_fibo(i)())