'''
Modes:
    r, w, a
    r, rt, rb    
    obj = open(path,mode)#loading contents from disk to memory
    obj.read()
    obj.readline()
    obj.write()
    obj.close()#write back the contents from buffer/memory to disk
'''

with open('fileTwo.py','r') as fObj:
    text = fObj.read()
    print(text)
    print(len(text))
