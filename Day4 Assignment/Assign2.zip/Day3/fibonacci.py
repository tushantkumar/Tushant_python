'''
memoization
'''
prevData = {0:0,1:1}
def  fibonacci(number):
    if number not in prevData:                
        prevData[number ] =(fibonacci(number-1)+fibonacci(number-2))
        
    return prevData[number]

import sys
import time
# numbers=int(input("enter number of terms"))
start = time.perf_counter()
print("fibonacci series:")
for i in range(int(sys.argv[1])):
    print(f'{i+1} -->{fibonacci(i)}')
print()
print(f'{round(time.perf_counter() - start, 5)} seconds')