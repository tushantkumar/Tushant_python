'''
'''

def greet(message):
    print(f'welcome with a {message}')
    def decorator(fun):
        def wrapper(arg):
            fun(arg)
        return wrapper
    print(f'Thank You for {message}')
    return decorator

@greet('Hello How are you')
def Test(val):
    print(f'val:{val}')

Test(10)