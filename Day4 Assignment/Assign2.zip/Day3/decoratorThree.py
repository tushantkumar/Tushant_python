'''    
  Decorators --> Higher Order Function
    which will perform function callback
'''

def logInfo(funAsArg): #HOF
    def wrapper_log(): #nested function for wrapping
        print('LogInfo started')
        funAsArg() # callback
        print('LogInfo Completed')
        print('-'* 50)
    return wrapper_log

@logInfo
def do_job():
    print('Job Done')
    
@logInfo
def do_db_job():
    print('DataBase Job Done')

do_job() #calling wrapperlog--> do_job
do_db_job() #calling wrapperlog--> do_db_job