'''    
  Decorators --> Higher Order Function
    which will perform function callback
'''

def logInfo(funAsArg): #HOF
    print('LogInfo started')
    funAsArg() # callback
    print('LogInfo Completed')
    print('-'* 50)

def do_job():
    print('Job Done')

def do_db_job():
    print('DataBase Job Done')

logInfo(do_job)
logInfo(do_db_job)