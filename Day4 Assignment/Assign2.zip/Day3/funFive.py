def fun(arg1,arg2):
    return f'arg1 {arg1}\targ2: {arg2}'


print(fun(10,20))