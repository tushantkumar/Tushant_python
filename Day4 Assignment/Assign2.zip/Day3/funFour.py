'''
def fun(arg1, arg2, arg3):
    pass
'''
def fun(arg, arg1=200, *args, **kwargs):
    pass

fun(1)
fun(2,a=10,b=20)
fun(10,20,30,40)