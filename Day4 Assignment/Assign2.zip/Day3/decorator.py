def logInfo(funAsArg):
    def wrapperLog():
        print('LogInfo Started')
        funAsArg()
        print('LogInfo Completed')
        print('-'*50)
    return wrapperLog    

@logInfo
def job_done():
    print('Job Done')

@logInfo
def job_completed():
    print('Job Completed')        

job_done()
job_completed()