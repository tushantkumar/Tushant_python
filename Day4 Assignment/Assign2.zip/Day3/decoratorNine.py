'''
'''
import time
def greet(fun): 
    start, end = time.perf_counter(), 0   
    def decorator(arg):
        nonlocal end
        val = fun(arg)
        end = time.perf_counter()
        
        return val   
        print(f'{end-start} seconds')        
    return decorator

@greet #('Put in Extra level of nesting')
def recur_fibo(n):
    if n <= 1:
        return n
    else:
        return(recur_fibo(n-1) + recur_fibo(n-2))

nterms = 20
print("Fibonacci Series is:")
for i in range(nterms):
       print(recur_fibo(i), end=" ")

