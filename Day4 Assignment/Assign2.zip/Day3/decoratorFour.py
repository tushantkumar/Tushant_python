def logInfo(funAsArg):
    import time
    start_time = time.perf_counter()
    
    def wrapperLog(args):
        var = funAsArg(args)
        return var
    
    end_time = time.perf_counter()
    print(f'{end_time - start_time}')
    print('-'*50)
        
    return wrapperLog    

@logInfo
def recur_fibo(n):    
    if n <= 1:
        #print(n)
        return n
    else:
        return(recur_fibo(n-1) + recur_fibo(n-2))

#recur_fibo(5)

nterms = 20
print("Fibonacci Series is:")
for i in range(nterms):
    print(recur_fibo(i))

'''

@logInfo
def recur_factorial(n):
    if n == 1:
        return n
    else:
        return n*recur_factorial(n-1)    
num = 20
print("The factorial of", num, "is", recur_factorial(num))      
recur_fibo(20)
recur_factorial(20)
'''