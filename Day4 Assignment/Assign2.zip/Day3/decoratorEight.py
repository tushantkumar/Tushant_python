'''
'''
def greet(func, message):
    print(f'welcome with a {message}')
    def decorator(fun):
        def wrapper(arg):
            val = fun(arg)
            func()
            print(f'Thank You for {message}')
            return val
        return wrapper
    
    return decorator

def funTest():
    print('func called')

@greet(funTest,'Hello How are you')
def Test(val):
    print(f'val:{val}')
    return val+10

print(f'main: {Test(10)}')