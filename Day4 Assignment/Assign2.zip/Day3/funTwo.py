'''
def fun(arg1, arg2, arg3):
    pass
'''


def fun(*args):#fun taking variable number of args thru tuple
    print(f'{args} ---->')

fun()
fun(1000)
fun(10,20)
fun(1,2,3,4,5,6)