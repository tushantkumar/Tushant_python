'''
def fun(arg1, arg2, arg3):
    pass
'''


def fun(arg1 = 1, arg2='some value', arg3 = 123.345):#fun with default args
    print(f'{arg1}-->{arg2}-->{arg3}')

fun()
fun(1000)
fun(10,20)