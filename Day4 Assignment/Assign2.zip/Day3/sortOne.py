'''
    lists
'''
lst = [i for i in range(40)]
print(lst)

lst.sort(reverse=True) # in-place sorting but returns nothing

print(lst)
print(sorted(lst)) #returns a new list which is sorted 
print(lst)
