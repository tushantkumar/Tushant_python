'''
def fun(arg1, arg2, arg3):
    pass
'''
def fun(**kwargs):#fun taking variable number of args thru dictionary
    print(f'{kwargs} ---->')

fun(n=10)
fun(arg1=1,arg2=2,arg3=3)
fun(first='Virat', last='Kohli')
